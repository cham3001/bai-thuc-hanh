
import { useEffect, useState } from "react";
import {
  BrowserProvider,
  Contract,
  formatEther,
  parseEther,
} from "ethers";
import abi from "./abi/DominionDAO.json";
import { CONTRACT_ADDRESS } from "./contractAddress";
import "./App.css";

const SEPOLIA_ID = "0xaa36a7";

export default function App() {
  const [account, setAccount] = useState("");
  const [contract, setContract] = useState(null);
  const [balance, setBalance] = useState("...");
  const [stakeholder, setStakeholder] = useState("Chưa kiểm tra");
  const [proposals, setProposals] = useState([]);
  const [status, setStatus] = useState("Chưa kết nối ví");
  const [busy, setBusy] = useState(false);

  const [amount, setAmount] = useState("0.01");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [beneficiary, setBeneficiary] = useState("");
  const [proposalAmount, setProposalAmount] = useState("0.001");

  function errorMessage(e) {
    return (
      e?.revert?.args?.[0] ||
      e?.reason ||
      e?.info?.error?.message ||
      e?.error?.message ||
      e?.shortMessage ||
      e?.message ||
      "Đã xảy ra lỗi không xác định."
    );
  }

  async function refresh(c = contract) {
    if (!c) return;

    try {
      const [b, list, isMember] = await Promise.all([
        c.getBalance(),
        c.getProposals(),
        c.isStakeholder(),
      ]);

      setBalance(formatEther(b));
      setProposals(Array.from(list));
      setStakeholder(
        isMember ? "Đã là Stakeholder" : "Chưa là Stakeholder"
      );
    } catch (e) {
      console.error("Lỗi tải dữ liệu DAO:", e);
      setStatus("Không đọc được dữ liệu: " + errorMessage(e));
    }
  }

  async function connectWallet() {
    try {
      if (!window.ethereum) {
        throw new Error("Hãy cài MetaMask trên trình duyệt.");
      }

      const provider = new BrowserProvider(window.ethereum);
      const network = await provider.getNetwork();

      if (network.chainId !== 11155111n) {
        throw new Error("Hãy chuyển MetaMask sang mạng Sepolia.");
      }

      const signer = await provider.getSigner();
      const address = await signer.getAddress();
      const c = new Contract(CONTRACT_ADDRESS, abi, signer);

      setAccount(address);
      setContract(c);
      setStatus("Đã kết nối ví. Đang tải dữ liệu...");

      await refresh(c);
      setStatus("Kết nối thành công trên Sepolia");
    } catch (e) {
      console.error("Lỗi kết nối ví:", e);
      setStatus(errorMessage(e));
    }
  }

  async function transact(action) {
    try {
      setBusy(true);
      setStatus("Đang gửi giao dịch...");

      const tx = await action();

      console.log("Transaction hash:", tx.hash);
      setStatus("Đã gửi giao dịch. Đang chờ xác nhận...");

      const receipt = await tx.wait();

      if (receipt.status !== 1) {
        throw new Error("Giao dịch thất bại trên blockchain.");
      }

      setStatus("Giao dịch thành công!");
      await refresh(contract);
    } catch (e) {
      console.error("DAO transaction error:", e);
      console.error("Error reason:", e?.reason);
      console.error("Error data:", e?.data);
      console.error("Error info:", e?.info);
      console.error("Error receipt:", e?.receipt);

      setStatus("Giao dịch thất bại: " + errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  async function contribute() {
    if (!contract) {
      setStatus("Hãy kết nối MetaMask trước.");
      return;
    }

    try {
      if (!Number.isFinite(Number(amount)) || Number(amount) <= 0) {
        setStatus("Số ETH đóng góp phải lớn hơn 0.");
        return;
      }

      const value = parseEther(amount);
      await transact(() => contract.contribute({ value }));
    } catch (e) {
      console.error("Lỗi đóng góp:", e);
      setStatus(errorMessage(e));
    }
  }

  async function createProposal() {
    if (!contract) {
      setStatus("Hãy kết nối MetaMask trước.");
      return;
    }

    if (!title.trim() || !description.trim() || !beneficiary.trim()) {
      setStatus("Hãy điền đủ tiêu đề, mô tả và địa chỉ người nhận.");
      return;
    }

    if (!/^0x[a-fA-F0-9]{40}$/.test(beneficiary.trim())) {
      setStatus("Địa chỉ người nhận không hợp lệ.");
      return;
    }

    try {
      if (
        !Number.isFinite(Number(proposalAmount)) ||
        Number(proposalAmount) <= 0
      ) {
        setStatus("Số ETH đề xuất phải lớn hơn 0.");
        return;
      }

      const value = parseEther(proposalAmount);

      // Kiểm tra quyền trước khi yêu cầu MetaMask gửi giao dịch.
      setBusy(true);
      setStatus("Đang kiểm tra quyền Stakeholder...");

      const isMember = await contract.isStakeholder();

      if (!isMember) {
        setStatus(
          "Hợp đồng hiện tại không nhận diện ví là Stakeholder. Chưa gửi giao dịch."
        );
        return;
      }

      // Mô phỏng lời gọi để phát hiện revert trước khi tốn gas.
      await contract.createProposal.staticCall(
        title.trim(),
        description.trim(),
        beneficiary.trim(),
        value
      );

      setBusy(false);

      await transact(() =>
        contract.createProposal(
          title.trim(),
          description.trim(),
          beneficiary.trim(),
          value
        )
      );
    } catch (e) {
      console.error("Lỗi tạo đề xuất:", e);
      console.error("Lý do:", e?.reason);
      console.error("Dữ liệu lỗi:", e?.data);
      console.error("Thông tin lỗi:", e?.info);

      setStatus("Không tạo được đề xuất: " + errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  async function vote(id, choice) {
    if (!contract) return;
    await transact(() => contract.performVote(id, choice));
  }

  async function payout(id) {
    if (!contract) return;
    await transact(() => contract.payBeneficiary(id));
  }

  useEffect(() => {
    if (!window.ethereum) return;

    const onAccounts = () => {
      setAccount("");
      setContract(null);
      setStakeholder("Chưa kiểm tra");
      setStatus("Ví thay đổi. Hãy kết nối lại.");
    };

    const onChain = () => window.location.reload();

    window.ethereum.on("accountsChanged", onAccounts);
    window.ethereum.on("chainChanged", onChain);

    return () => {
      window.ethereum.removeListener("accountsChanged", onAccounts);
      window.ethereum.removeListener("chainChanged", onChain);
    };
  }, []);

  function field(p, name, index) {
    return p[name] ?? p[index];
  }

  return (
    <main className="app">
      <header>
        <p className="eyebrow">WEB3 · SEPOLIA TESTNET</p>
        <h1>DominionDAO</h1>
        <p>Ứng dụng quản trị DAO bằng smart contract</p>

        <button onClick={connectWallet} disabled={busy}>
          {account
            ? `${account.slice(0, 6)}...${account.slice(-4)}`
            : "Kết nối MetaMask"}
        </button>

        <p className="status">{status}</p>
      </header>

      <section className="panel">
        <h2>Số dư đóng góp của ví</h2>
        <p className="big">{balance} ETH</p>
        <p>Trạng thái Stakeholder: {stakeholder}</p>

        <button
          className="secondary"
          onClick={() => refresh()}
          disabled={!contract || busy}
        >
          Làm mới dữ liệu
        </button>
      </section>

      <section className="panel">
        <h2>Đóng góp ETH</h2>
        <label>Số ETH muốn đóng góp</label>
        <input
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          type="number"
          min="0.001"
          step="0.001"
        />

        <button onClick={contribute} disabled={!contract || busy}>
          {busy ? "Đang xử lý..." : "Đóng góp"}
        </button>

        <p className="hint">
          Theo hợp đồng, cần đóng góp tổng cộng ít nhất 0.01 ETH
          để trở thành Stakeholder.
        </p>
      </section>

      <section className="panel">
        <h2>Tạo đề xuất</h2>

        <label>Tiêu đề</label>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />

        <label>Mô tả</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        <label>Địa chỉ người nhận (beneficiary)</label>
        <input
          value={beneficiary}
          onChange={(e) => setBeneficiary(e.target.value)}
        />

        <label>Số ETH đề xuất</label>
        <input
          type="number"
          min="0.001"
          step="0.001"
          value={proposalAmount}
          onChange={(e) => setProposalAmount(e.target.value)}
        />

        <button
          onClick={createProposal}
          disabled={!contract || busy}
        >
          {busy ? "Đang xử lý..." : "Tạo đề xuất"}
        </button>
      </section>

      <section className="panel">
        <h2>Danh sách đề xuất</h2>

        {!proposals.length && (
          <p>Chưa có đề xuất hoặc chưa tải được dữ liệu.</p>
        )}

        {proposals.map((p, i) => {
          const id = field(p, "id", 0);
          const value = field(p, "amount", 1);
          const up = field(p, "upvotes", 3);
          const down = field(p, "downvotes", 4);
          const name = field(p, "title", 5);
          const desc = field(p, "description", 6);
          const passed = field(p, "passed", 7);
          const paid = field(p, "paid", 8);
          const to = field(p, "beneficiary", 9);

          return (
            <article className="proposal" key={String(id ?? i)}>
              <h3>{name || `Đề xuất ${String(id)}`}</h3>
              <p>{desc}</p>
              <p>Số tiền: {formatEther(value)} ETH</p>
              <p>Ủng hộ: {String(up)} · Phản đối: {String(down)}</p>
              <p>Người nhận: {String(to)}</p>
              <p>
                Trạng thái:{" "}
                {paid
                  ? "Đã thanh toán"
                  : passed
                    ? "Đã thông qua"
                    : "Chưa thanh toán"}
              </p>

              <div className="actions">
                <button
                  onClick={() => vote(id, true)}
                  disabled={!contract || busy}
                >
                  Ủng hộ
                </button>

                <button
                  className="secondary"
                  onClick={() => vote(id, false)}
                  disabled={!contract || busy}
                >
                  Phản đối
                </button>

                <button
                  className="secondary"
                  onClick={() => payout(id)}
                  disabled={!contract || busy}
                >
                  Thanh toán
                </button>
              </div>
            </article>
          );
        })}
      </section>

      <footer>
        DominionDAO · Bài thực hành Smart Contract & React
      </footer>
    </main>
  );
}
