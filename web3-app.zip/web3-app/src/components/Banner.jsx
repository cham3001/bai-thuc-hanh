
import { useState } from 'react';
import { useGlobalState, setGlobalState } from '../store';
import { toast } from 'react-toastify';
import { performContribute } from '../Blockchain.services';

const Banner = () => {
  const [isStakeholder] = useGlobalState('isStakeholder');
  const [proposals] = useGlobalState('proposals');
  const [balance] = useGlobalState('balance');
  const [mybalance] = useGlobalState('mybalance');
  const [amount, setAmount] = useState('');

  const onPropose = () => {
    if (!isStakeholder) return;
    setGlobalState('createModal', 'scale-100');
  };

  const onContribute = async () => {
    if (!amount || amount === '') return;

    const result = await performContribute(amount);

    if (result instanceof Error) {
      toast.error(result.message || 'Contribution failed');
      return;
    }

    toast.success('Contribution received');
  };

  const opened = () =>
    proposals.filter(
      (proposal) =>
        new Date().getTime() < Number(proposal.duration + '000')
    ).length;

  return (
    <div className="p-8">
      <h2 className="font-semibold text-3xl mb-5">
        {opened()} Proposal{opened() === 1 ? '' : 's'} Currently Opened
      </h2>

      <p>
        Current DAO Balance: <strong>{balance} Eth</strong>
        <br />
        Your contributions:{' '}
        <span>
          <strong>{mybalance} Eth</strong>
          {isStakeholder
            ? ', and you are now a stakeholder 😊'
            : null}
        </span>
      </p>

      <hr className="my-6 border-gray-300 dark:border-gray-500" />

      <p>
        {isStakeholder
          ? 'You can now raise proposals on this platform 😆'
          : 'Contribute to become a stakeholder 😎'}
      </p>

      <div className="flex flex-row justify-start items-center md:w-1/3 w-full mt-4">
        <input
          type="number"
          min="0"
          step="any"
          className="block w-full px-3 py-1.5 text-base text-gray-700 bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 shadow-md focus:outline-none dark:border-gray-500 dark:bg-transparent"
          placeholder="e.g. 0.01 ETH"
          onChange={(e) => setAmount(e.target.value)}
          value={amount}
          required
        />
      </div>

      <div
        className="flex flex-row justify-start items-center space-x-3 mt-4"
        role="group"
      >
        <button
          type="button"
          className="inline-block px-6 py-2.5 bg-blue-600 text-white font-medium text-xs leading-tight uppercase shadow-md rounded-full hover:bg-blue-700 transition"
          onClick={onContribute}
        >
          Contribute
        </button>

        {isStakeholder ? (
          <button
            type="button"
            className="inline-block px-6 py-2.5 bg-blue-600 text-white font-medium text-xs leading-tight uppercase shadow-md rounded-full hover:bg-blue-700 transition"
            onClick={onPropose}
          >
            Propose
          </button>
        ) : null}
      </div>
    </div>
  );
};

export default Banner;
