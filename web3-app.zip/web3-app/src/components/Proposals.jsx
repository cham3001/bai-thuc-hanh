
import { useEffect, useState } from 'react';
import Identicon from 'react-identicons';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import {
  truncate,
  useGlobalState,
  daysRemaining,
} from '../store';
import { payoutBeneficiary } from '../Blockchain.services';

const Proposals = () => {
  const [data] = useGlobalState('proposals');
  const [proposals, setProposals] = useState(data);

  useEffect(() => {
    setProposals(data);
  }, [data]);

  const deactive = `
    bg-transparent text-blue-600 font-medium text-xs
    uppercase border border-blue-600
    hover:bg-blue-700 hover:text-white transition
  `;

  const active = `
    bg-blue-600 text-white font-medium text-xs
    uppercase border border-blue-600
  `;

  const getAll = () => setProposals(data);

  const getOpened = () => {
    setProposals(
      data.filter(
        (proposal) =>
          Date.now() < Number(proposal.duration) * 1000
      )
    );
  };

  const getClosed = () => {
    setProposals(
      data.filter(
        (proposal) =>
          Date.now() >= Number(proposal.duration) * 1000
      )
    );
  };

  const handlePayout = async (id) => {
    await payoutBeneficiary(id);
    toast.success('Beneficiary successfully paid out!');
  };

  return (
    <div className="flex flex-col p-8">
      <div
        className="flex flex-row justify-center items-center"
        role="group"
      >
        <button
          type="button"
          className={`rounded-l-full px-6 py-2.5 ${active}`}
          onClick={getAll}
        >
          All
        </button>

        <button
          type="button"
          className={`px-6 py-2.5 ${deactive}`}
          onClick={getOpened}
        >
          Open
        </button>

        <button
          type="button"
          className={`rounded-r-full px-6 py-2.5 ${deactive}`}
          onClick={getClosed}
        >
          Closed
        </button>
      </div>

      <div className="overflow-x-auto">
        <div className="py-2 inline-block min-w-full">
          <div className="overflow-y-auto shadow-md rounded-md">
            <table className="min-w-full">
              <thead className="border-b dark:border-gray-500">
                <tr>
                  <th className="text-sm font-medium px-6 py-4 text-left">
                    Created By
                  </th>
                  <th className="text-sm font-medium px-6 py-4 text-left">
                    Title
                  </th>
                  <th className="text-sm font-medium px-6 py-4 text-left">
                    Expires
                  </th>
                  <th className="text-sm font-medium px-6 py-4 text-left">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {proposals.map((proposal) => {
                  const expired =
                    Date.now() >= Number(proposal.duration) * 1000;

                  return (
                    <tr
                      key={String(proposal.id)}
                      className="border-b dark:border-gray-500"
                    >
                      <td className="text-sm px-6 py-4 whitespace-nowrap">
                        <div className="flex flex-row items-center space-x-3">
                          <Identicon
                            string={String(proposal.proposer).toLowerCase()}
                            size={25}
                          />
                          <span>
                            {truncate(proposal.proposer, 4, 4, 11)}
                          </span>
                        </div>
                      </td>

                      <td className="text-sm px-6 py-4">
                        {proposal.title.length > 80
                          ? `${proposal.title.substring(0, 80)}...`
                          : proposal.title}
                      </td>

                      <td className="text-sm px-6 py-4 whitespace-nowrap">
                        {expired
                          ? 'Expired'
                          : daysRemaining(proposal.duration)}
                      </td>

                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <Link
                            to={`/proposal/${proposal.id}`}
                            className="rounded-full px-5 py-2 bg-blue-600 text-white text-xs uppercase"
                          >
                            View
                          </Link>

                          {expired &&
                          Number(proposal.upvotes) >
                            Number(proposal.downvotes) ? (
                            proposal.paid ? (
                              <span className="text-green-600 text-xs">
                                Paid
                              </span>
                            ) : (
                              <button
                                type="button"
                                className="rounded-full px-5 py-2 bg-red-600 text-white text-xs uppercase"
                                onClick={() => handlePayout(proposal.id)}
                              >
                                Payout
                              </button>
                            )
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {proposals.length === 0 && (
              <p className="p-6 text-center">
                No proposals found.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Proposals;
