
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import {
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis,
  Legend,
  Tooltip,
} from 'recharts';
import {
  getProposal,
  voteOnProposal,
} from '../Blockchain.services';
import { useGlobalState, daysRemaining } from '../store';

const ProposalDetails = () => {
  const { id } = useParams();

  const [proposal, setProposal] = useState(null);
  const [data, setData] = useState([]);
  const [isStakeholder] = useGlobalState('isStakeholder');

  useEffect(() => {
    const retrieveProposal = async () => {
      const result = await getProposal(id);

      setProposal(result || null);

      if (result) {
        setData([
          {
            name: 'Voters',
            Acceptees: Number(result.upvotes),
            Rejectees: Number(result.downvotes),
          },
        ]);
      } else {
        setData([]);
      }
    };

    retrieveProposal();
  }, [id]);

  const onVote = async (choice) => {
    if (!proposal) return;

    if (Date.now() >= Number(proposal.duration) * 1000) {
      toast.warning('Proposal expired!');
      return;
    }

    await voteOnProposal(id, choice);
    toast.success('Voted successfully!');
  };

  if (!proposal) {
    return (
      <div className="p-8">
        Proposal not found. Please return to the home page.
      </div>
    );
  }

  const totalVotes =
    Number(proposal.upvotes) + Number(proposal.downvotes);

  const expired =
    Date.now() >= Number(proposal.duration) * 1000;

  return (
    <div className="p-8">
      <h2 className="font-semibold text-3xl mb-5">
        {proposal.title}
      </h2>

      <p>
        This proposal is to payout{' '}
        <strong>{proposal.amount} ETH</strong> and currently has{' '}
        <strong>{totalVotes} votes</strong>.
        {expired
          ? ' Voting has expired.'
          : ` It will expire in ${daysRemaining(proposal.duration)}.`}
      </p>

      <hr className="my-6 border-gray-300" />

      <p>{proposal.description}</p>

      <div className="w-full mt-4 overflow-x-auto">
        <BarChart width={730} height={250} data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="Acceptees" fill="#2563eb" />
          <Bar dataKey="Rejectees" fill="#dc2626" />
        </BarChart>
      </div>

      {isStakeholder && !expired && (
        <div
          className="flex flex-row items-center gap-3 mt-4"
          role="group"
        >
          <button
            type="button"
            className="rounded-full px-6 py-2.5 bg-blue-600 text-white text-xs uppercase"
            onClick={() => onVote(true)}
          >
            Accept
          </button>

          <button
            type="button"
            className="rounded-full px-6 py-2.5 bg-red-600 text-white text-xs uppercase"
            onClick={() => onVote(false)}
          >
            Reject
          </button>
        </div>
      )}
    </div>
  );
};

export default ProposalDetails;
