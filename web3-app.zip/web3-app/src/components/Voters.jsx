
import { useState, useEffect } from 'react';
import Identicon from 'react-identicons';
import moment from 'moment';
import { useParams } from 'react-router-dom';
import { truncate } from '../store';
import { listVoters } from '../Blockchain.services';

const Voters = () => {
  const [voters, setVoters] = useState([]);
  const [allVoters, setAllVoters] = useState([]);
  const { id } = useParams();

  useEffect(() => {
    const fetchVoters = async () => {
      const result = await listVoters(id);
      const voteList = Array.isArray(result) ? result : [];

      setAllVoters(voteList);
      setVoters(voteList);
    };

    fetchVoters();
  }, [id]);

  const getAll = () => {
    setVoters(allVoters);
  };

  const getAccepted = () => {
    setVoters(
      allVoters.filter((voter) => voter.choosen)
    );
  };

  const getRejected = () => {
    setVoters(
      allVoters.filter((voter) => !voter.choosen)
    );
  };

  const timeAgo = (timestamp) =>
    moment(Number(timestamp) * 1000).fromNow();

  const buttonBase =
    'px-6 py-2.5 text-xs uppercase border border-blue-600 transition';

  return (
    <div className="flex flex-col p-8">
      <div
        className="flex flex-row justify-center items-center"
        role="group"
      >
        <button
          type="button"
          className={`${buttonBase} rounded-l-full bg-blue-600 text-white`}
          onClick={getAll}
        >
          All
        </button>

        <button
          type="button"
          className={`${buttonBase} bg-transparent text-blue-600`}
          onClick={getAccepted}
        >
          Acceptees
        </button>

        <button
          type="button"
          className={`${buttonBase} rounded-r-full bg-transparent text-blue-600`}
          onClick={getRejected}
        >
          Rejectees
        </button>
      </div>

      <div className="overflow-x-auto">
        <div className="py-2 inline-block min-w-full">
          <div className="overflow-y-auto shadow-md rounded-md">
            <table className="min-w-full">
              <thead className="border-b dark:border-gray-500">
                <tr>
                  <th className="text-sm font-medium px-6 py-4 text-left">
                    Voter
                  </th>
                  <th className="text-sm font-medium px-6 py-4 text-left">
                    Voted
                  </th>
                  <th className="text-sm font-medium px-6 py-4 text-left">
                    Vote
                  </th>
                </tr>
              </thead>

              <tbody>
                {voters.map((voter, index) => (
                  <tr
                    key={`${voter.voter}-${index}`}
                    className="border-b dark:border-gray-500"
                  >
                    <td className="text-sm px-6 py-4 whitespace-nowrap">
                      <div className="flex flex-row items-center gap-3">
                        <Identicon
                          string={String(voter.voter).toLowerCase()}
                          size={25}
                        />
                        <span>
                          {truncate(voter.voter, 4, 4, 11)}
                        </span>
                      </div>
                    </td>

                    <td className="text-sm px-6 py-4 whitespace-nowrap">
                      {timeAgo(voter.timestamp)}
                    </td>

                    <td className="text-sm px-6 py-4 whitespace-nowrap">
                      {voter.choosen ? (
                        <span className="text-blue-600">
                          Accepted
                        </span>
                      ) : (
                        <span className="text-red-600">
                          Rejected
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {voters.length === 0 && (
              <p className="p-6 text-center">
                No votes found.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Voters;
