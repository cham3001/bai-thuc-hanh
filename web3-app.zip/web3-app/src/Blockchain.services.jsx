
import Web3 from "web3";
import { setGlobalState, getGlobalState } from "./store";
import abi from "./abis/DominionDAO.json";

// Khởi tạo Web3 từ provider của MetaMask, không dùng window.web3
let web3Instance = null;

const getWeb3Instance = () => {
  if (!window.ethereum) {
    throw new Error("Please install MetaMask.");
  }

  const Web3Constructor =
    typeof Web3 === "function" ? Web3 : Web3.default;

  if (typeof Web3Constructor !== "function") {
    throw new Error("Cannot initialize Web3.");
  }

  if (
    !web3Instance ||
    !web3Instance.eth ||
    typeof web3Instance.eth.Contract !== "function"
  ) {
    web3Instance = new Web3Constructor(window.ethereum);
  }

  if (
    !web3Instance.eth ||
    typeof web3Instance.eth.Contract !== "function"
  ) {
    throw new Error("Web3 initialization failed.");
  }

  return web3Instance;
};

// ABI trong file của bà là mảng JSON trực tiếp
const contractAbi = Array.isArray(abi) ? abi : abi.abi;

// Kết nối ví MetaMask
const connectWallet = async () => {
  try {
    if (!window.ethereum) {
      alert("Please install MetaMask.");
      return;
    }

    const accounts = await window.ethereum.request({
      method: "eth_requestAccounts",
    });

    if (!accounts || accounts.length === 0) {
      throw new Error("No MetaMask account selected.");
    }

    setGlobalState(
      "connectedAccount",
      accounts[0].toLowerCase()
    );
  } catch (error) {
    reportError(error);
  } finally {
    window.location.reload();
  }
};

// Kiểm tra trạng thái kết nối ví
const isWallectConnected = async () => {
  try {
    if (!window.ethereum) {
      console.warn("Please install MetaMask.");
      return;
    }

    const accounts = await window.ethereum.request({
      method: "eth_accounts",
    });

    window.ethereum.on("chainChanged", () => {
      window.location.reload();
    });

    window.ethereum.on("accountsChanged", (currentAccounts) => {
      setGlobalState(
        "connectedAccount",
        currentAccounts.length
          ? currentAccounts[0].toLowerCase()
          : ""
      );

      window.location.reload();
    });

    if (accounts.length > 0) {
      setGlobalState(
        "connectedAccount",
        accounts[0].toLowerCase()
      );
    } else {
      setGlobalState("connectedAccount", "");
    }
  } catch (error) {
    reportError(error);
  }
};

// Khởi tạo hợp đồng DominionDAO
const getEtheriumContract = async () => {
  const connectedAccount = getGlobalState("connectedAccount");

  if (!connectedAccount) {
    return getGlobalState("contract");
  }

  const web3 = getWeb3Instance();
  const contractAddress =
    process.env.REACT_APP_CONTRACT_ADDRESS;

  if (!contractAddress) {
    throw new Error(
      "Missing REACT_APP_CONTRACT_ADDRESS in .env"
    );
  }

  if (!Array.isArray(contractAbi) || contractAbi.length === 0) {
    throw new Error("DominionDAO ABI is invalid or empty.");
  }

  const contract = new web3.eth.Contract(
    contractAbi,
    contractAddress
  );

  setGlobalState("contract", contract);

  return contract;
};

// Đóng góp ETH cho DAO
const performContribute = async (amount) => {
  try {
    const web3 = getWeb3Instance();

    const value = web3.utils.toWei(
      amount.toString(),
      "ether"
    );

    const contract = await getEtheriumContract();
    const account = getGlobalState("connectedAccount");

    if (!contract || !account) {
      throw new Error("Please connect wallet.");
    }

    await contract.methods.contribute().send({
      from: account,
      value,
    });

    window.location.reload();
  } catch (error) {
    reportError(error);
    return error;
  }
};

// Lấy số dư DAO, số dư đóng góp và trạng thái stakeholder
const getInfo = async () => {
  try {
    if (!window.ethereum) {
      console.warn("Please install MetaMask.");
      return;
    }

    const connectedAccount =
      getGlobalState("connectedAccount");

    if (!connectedAccount) return;

    const contract = await getEtheriumContract();

    if (!contract) return;

    const isStakeholder = await contract.methods
      .isStakeholder()
      .call({ from: connectedAccount });

    const balance = await contract.methods
      .daoBalance()
      .call();

    const mybalance = await contract.methods
      .getBalance()
      .call({ from: connectedAccount });

    const web3 = getWeb3Instance();

    setGlobalState(
      "balance",
      web3.utils.fromWei(balance.toString(), "ether")
    );

    setGlobalState(
      "mybalance",
      web3.utils.fromWei(mybalance.toString(), "ether")
    );

    setGlobalState("isStakeholder", isStakeholder);
  } catch (error) {
    reportError(error);
  }
};

// Tạo proposal
const raiseProposal = async ({
  title,
  description,
  beneficiary,
  amount,
}) => {
  try {
    const web3 = getWeb3Instance();

    const amountWei = web3.utils.toWei(
      amount.toString(),
      "ether"
    );

    const contract = await getEtheriumContract();
    const account = getGlobalState("connectedAccount");

    if (!contract || !account) {
      throw new Error("Please connect wallet.");
    }

    await contract.methods
      .createProposal(
        title,
        description,
        beneficiary,
        amountWei
      )
      .send({ from: account });

    window.location.reload();
  } catch (error) {
    reportError(error);
    return error;
  }
};

// Chuẩn hóa dữ liệu proposal cho giao diện
const structuredProposals = (proposals) => {
  const web3 = getWeb3Instance();

  return proposals
    .map((proposal) => ({
      id: proposal.id,
      amount: web3.utils.fromWei(
        proposal.amount.toString(),
        "ether"
      ),
      title: proposal.title,
      description: proposal.description,
      paid: proposal.paid,
      passed: proposal.passed,
      proposer: proposal.proposer,
      upvotes: Number(proposal.upvotes),
      downvotes: Number(proposal.downvotes),
      beneficiary: proposal.beneficiary,
      executor: proposal.executor,
      duration: proposal.duration,
    }))
    .reverse();
};

// Lấy danh sách proposal
const getProposals = async () => {
  try {
    if (!window.ethereum) {
      console.warn("Please install MetaMask.");
      return;
    }

    if (!getGlobalState("connectedAccount")) return;

    const contract = await getEtheriumContract();

    if (!contract) return;

    const proposals = await contract.methods
      .getProposals()
      .call();

    setGlobalState(
      "proposals",
      structuredProposals(proposals)
    );
  } catch (error) {
    reportError(error);
  }
};

// Lấy một proposal từ danh sách đã tải
const getProposal = async (id) => {
  try {
    const proposals = getGlobalState("proposals");

    return proposals.find(
      (proposal) => String(proposal.id) === String(id)
    );
  } catch (error) {
    reportError(error);
  }
};

// Bỏ phiếu: true = Accept, false = Reject
const voteOnProposal = async (proposalId, supported) => {
  try {
    const contract = await getEtheriumContract();
    const account = getGlobalState("connectedAccount");

    if (!contract || !account) {
      throw new Error("Please connect wallet.");
    }

    await contract.methods
      .performVote(proposalId, supported)
      .send({ from: account });

    window.location.reload();
  } catch (error) {
    reportError(error);
    return error;
  }
};

// Lấy danh sách người bỏ phiếu
const listVoters = async (id) => {
  try {
    const contract = await getEtheriumContract();

    if (!contract) return [];

    return await contract.methods
      .getVotesOf(id)
      .call();
  } catch (error) {
    reportError(error);
    return [];
  }
};

// Thanh toán cho người thụ hưởng
const payoutBeneficiary = async (id) => {
  try {
    const contract = await getEtheriumContract();
    const account = getGlobalState("connectedAccount");

    if (!contract || !account) {
      throw new Error("Please connect wallet.");
    }

    await contract.methods
      .payBeneficiary(id)
      .send({ from: account });

    window.location.reload();
  } catch (error) {
    reportError(error);
    return error;
  }
};

// Ghi lỗi ra Console để tiện kiểm tra
const reportError = (error) => {
  console.error("DominionDAO error:", error);
};

export {
  isWallectConnected,
  connectWallet,
  performContribute,
  getInfo,
  raiseProposal,
  getProposals,
  getProposal,
  voteOnProposal,
  listVoters,
  payoutBeneficiary,
};
